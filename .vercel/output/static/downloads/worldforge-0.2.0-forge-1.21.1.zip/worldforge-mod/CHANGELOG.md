# Changelog

## 0.2.0 — 2026-09-28

### Added

- Phase 6 world systems: dimension snapshot, authored regions, points of interest, pack-authored world events
- Persistent regions and POIs in SavedData (schema 2)
- `/worldforge world`
- `/worldforge region list|here`
- `/worldforge poi list|here`
- `/worldforge event list|<type> <payload>`

### Notes

- Regions are never discovered by scanning chunks
- World events are ephemeral; geography persists across restarts
- A modpack fingerprint change still clears integration state, not authored geography

## 0.1.0 — 2026-09-25

### Added

- Phase 1–5 foundation for Minecraft 1.21.1 / Forge 52.1.0
- Mod discovery from Forge loader metadata
- One-shot Forge and datapack registry census
- Knowledge classification: KNOWN / PARTIALLY_KNOWN / UNKNOWN
- Persistent world knowledge with schema version and modpack fingerprint
- Integration manager with magic, combat, technology, quest, and worldgen adapters (detect-only)
- `/worldforge status|discover|knowledge`
- Common config for debug, discovery, integrations, and experimental features
