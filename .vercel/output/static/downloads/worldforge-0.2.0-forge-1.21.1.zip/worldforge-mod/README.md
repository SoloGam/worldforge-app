# WorldForge

An extensible world-engine framework for **Minecraft 1.21.1 / Forge 52.1.0**.

WorldForge is not a content mod. It is an integration and orchestration layer for large modpacks: it discovers what is actually installed, classifies how much of it can be inspected, and exposes a stable API for adapters that talk to other mods through **their official surfaces**.

If a mod provides an API, WorldForge uses the API.  
If it exposes registries, WorldForge counts them.  
If it provides nothing useful, WorldForge marks it **UNKNOWN**. It does not reverse-engineer.

## Status

**Phase 6 world systems (0.2.0).** Loader, discovery, knowledge, persistence, adapters, dimension snapshots, authored regions, POIs, and a pack-authored world event bus are in place. Domain adapters still **refuse to bind** until a real public API is wired — that is intentional.

| Phase | Scope | State |
| --- | --- | --- |
| 1 | Forge setup, config, logging, lifecycle | Done |
| 2 | Service architecture, events, data layer | Done |
| 3 | Mod discovery, registry census, knowledge | Done |
| 4 | Persistent world/modpack knowledge + versioning | Done |
| 5 | Generic adapters + integration manager | Done (bindings later) |
| 6 | World systems (regions, POIs, environment) | Done |
| 7–8 | Magic / combat integration | Stubs |
| 9–10 | Advanced systems, optimisation | Not started |

## Requirements

- JDK 21
- Minecraft 1.21.1
- Forge 52.1.0 (recommended)

## Build

```bash
./gradlew genIntellijRuns
./gradlew build
./gradlew runClient
```

The Gradle wrapper is included. First run downloads Minecraft mappings and Forge — expect several minutes.

## In-game

Operator command (permission 2):

```
/worldforge status
/worldforge discover
/worldforge knowledge
/worldforge world
/worldforge region list
/worldforge region here
/worldforge poi list
/worldforge poi here
/worldforge event list
/worldforge event raid village_bell
```

Common config (`worldforge-common.toml`):

- `debugMode` — verbose category logs
- `discoveryOnStartup` — scan mods during common setup
- `scanDatapackRegistries` — census biomes/enchantments/structures on server start
- `integrations.*` — enable/disable adapter families
- `experimentalFeatures` — reserved for high-volume events (off)

## Architecture

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) and [docs/ROADMAP.md](docs/ROADMAP.md).

Package layout:

```
net.worldforge
  api/           Stable types other mods may compile against
  api/world/     Snapshot, Region, POI, WorldEvent
  core/          Bootstrap, config, logging, services
  discovery/     Loader metadata + registry census
  knowledge/     KNOWN / PARTIALLY_KNOWN / UNKNOWN
  persistence/   SavedData, schema version, fingerprint
  integration/   Adapter manager + domain adapters
  event/         Narrow Forge event router
  world/         World-state façade
  command/       Diagnostics
```

## Compatibility

WorldForge has **no optional Maven dependencies**. Target mods are detected at runtime with `ModList.isLoaded`. A missing magic/tech/quest mod never crashes the loader.

## License

MIT. Minecraft and Forge are property of their respective owners. Official mappings are used under Mojang's mapping license.
