# WorldForge architecture

## Layering

```
Minecraft
  → Forge
    → WorldForge Core
      → World / simulation systems
        → Compatibility & integration layer
          → Other mods (via adapters)
```

Core never hard-codes support for a third-party mod. Adapters live beside the core and fail closed.

## Honesty contract

Every discovered mod is classified:

| Status | Meaning |
| --- | --- |
| `KNOWN` | Platform (minecraft/forge/worldforge) **or** a bound adapter using a public API |
| `PARTIALLY_KNOWN` | Registries or an integration point are visible; mechanics are not adapted |
| `UNKNOWN` | Loader metadata only |

WorldForge will not invent behaviour for UNKNOWN mods.

## Knowledge scopes

| Scope | Lives where | Travels with |
| --- | --- | --- |
| CORE | Code | The jar |
| MODPACK | Fingerprint of installed mod ids+versions | The pack |
| WORLD | `SavedData` (`worldforge`) | The save |
| PLAYER | Future | The player |

Opening a world under a different modpack fingerprint **clears** world integration state instead of applying stale adapters.

## Discovery

Two cheap, one-shot passes:

1. **Common setup** — `ModList` metadata + Forge registries (blocks, items, entities, effects, recipe serializers).
2. **Server start** — datapack registries (biomes, enchantments, structures) via `RegistryAccess`.

No world scans. No per-tick reflection. Results are cached on `ModDiscoveryService`.

## Events

`EventRouter` subscribes only to lifecycle events (server start/stop, login/logout, dimension change). High-volume block/entity events are not registered. An `experimentalFeatures` flag is reserved for later.

## Adapters

`IntegrationManager` owns domain adapters (magic, combat, technology, quest, worldgen). Each adapter lists target mod ids but those ids are **not** Forge dependencies. `tryBind()` must catch its own failures. Phase 5 adapters detect presence and then **refuse to bind** until an official API is implemented.

## Persistence

`WorldForgeSavedData` stores schema version (currently 2), modpack fingerprint, a compound world-knowledge tag, authored regions, and points of interest. Schema mismatches rewrite forward; fingerprint mismatches discard **integration** state, not geography.

## World systems (Phase 6)

- **Dimension snapshot** — time, weather, difficulty, captured on demand (server start, login, `/worldforge world`). No ticker.
- **Regions** — operator- or API-authored circles. Never produced by a chunk scan.
- **POIs** — named points, optionally parented to a region.
- **World event bus** — pack-authored signals (`raid`, `season`, …). Ephemeral, capacity 64, not Forge's event bus.

## Performance rules

- Event-driven, not ticker-driven
- Cache discovery
- Debug logging only when `debugMode` is true
- Never block the main thread on I/O beyond a single SavedData read/write
