# Compatibility

WorldForge must keep running when other mods are missing, added, removed, updated, or only partially inspectable.

## Rules

1. **No hard optional dependencies.** Target mods are detected with `ModList.isLoaded`. They are never Maven `implementation` lines in 0.1.0.
2. **Adapters fail closed.** `tryBind()` is wrapped by `IntegrationManager`. A thrown exception unbinds that adapter and is logged under `[WorldForge:Integration]`.
3. **Fingerprint isolation.** World saved data stores the pack fingerprint. A mismatch clears world integration state.
4. **Honest status.** UNKNOWN is a valid, stable result. It is not a bug and not a prompt to scrape private classes.
5. **Config kill-switches.** Each adapter family can be disabled by operators without removing the jar.

## 0.1.0 adapter policy

Domain adapters list well-known mod ids as *targets*, not as contracts. Until a documented API is wired, `tryBind()` returns false with `SKIPPED_NO_API` even if the target is loaded.
