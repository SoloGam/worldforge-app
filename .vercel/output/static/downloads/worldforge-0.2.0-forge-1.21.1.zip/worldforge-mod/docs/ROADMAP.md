# Roadmap

## Done — 0.1.0 (Phases 1–5)

- Forge 1.21.1 / 52.1.0 workspace
- Config, structured logging, lifecycle
- Service registry
- Mod discovery + registry census
- Knowledge layer with honest status
- Persistent SavedData + schema + fingerprint
- Integration manager and domain adapter stubs
- `/worldforge` diagnostics

## Done — 0.2.0 (Phase 6)

- Dimension snapshot (time, weather, difficulty)
- Region registry (authored, not a world scan)
- Point-of-interest API
- Pack-authored world event bus
- SavedData schema 2

## Next — Phase 7–8

- Magic adapter for one mod with a **documented** API (likely Ars Nouveau), compiled as an optional source set or isolated module
- Combat adapter over vanilla damage types; Apotheosis only if its API is used

## Later — Phase 9–10

- Public event bus for other mods
- Data generators for adapter descriptors
- Compatibility test pack
- Profiling pass (allocation, registry census cost on 200-mod packs)

## Non-goals for 0.x

- Shipping gameplay content
- Mixins against other mods
- Downloading code at runtime
- Pretending to understand closed systems
