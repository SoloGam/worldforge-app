package net.worldforge.core;

import net.minecraft.server.MinecraftServer;
import net.worldforge.api.WorldForgeAPI;
import net.worldforge.api.discovery.DiscoveredMod;
import net.worldforge.api.event.EngineEvent;
import net.worldforge.api.integration.Adapter;
import net.worldforge.api.integration.AdapterState;
import net.worldforge.api.integration.IntegrationDomain;
import net.worldforge.api.knowledge.ModKnowledge;
import net.worldforge.api.world.DimensionSnapshot;
import net.worldforge.api.world.PointOfInterest;
import net.worldforge.api.world.Region;
import net.worldforge.api.world.WorldEvent;
import net.worldforge.core.config.WorldForgeConfig;
import net.worldforge.core.logging.LogCategory;
import net.worldforge.core.logging.WorldForgeLog;
import net.worldforge.core.services.ServiceRegistry;
import net.worldforge.discovery.ModDiscoveryService;
import net.worldforge.integration.IntegrationManager;
import net.worldforge.knowledge.KnowledgeLayer;
import net.worldforge.world.WorldStateService;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * Orchestrates discovery, knowledge, adapters, and world persistence.
 * Deliberately not a god-object: each concern is a dedicated service.
 */
public final class WorldForgeCore implements WorldForgeAPI {
    public static final String VERSION = "0.2.0";

    private final ServiceRegistry services = new ServiceRegistry();
    private final ModDiscoveryService discovery = new ModDiscoveryService();
    private final KnowledgeLayer knowledge = new KnowledgeLayer();
    private final IntegrationManager integrations = new IntegrationManager();
    private final WorldStateService world = new WorldStateService();
    private boolean bootstrapped;

    public WorldForgeCore() {
        services.register(ModDiscoveryService.class, discovery);
        services.register(KnowledgeLayer.class, knowledge);
        services.register(IntegrationManager.class, integrations);
        services.register(WorldStateService.class, world);
    }

    public ServiceRegistry services() {
        return services;
    }

    public synchronized void bootstrap() {
        if (bootstrapped) {
            return;
        }
        WorldForgeLog.info(LogCategory.CORE, "WorldForge %s — Phase 6 world systems", VERSION);
        if (WorldForgeConfig.discoveryOnStartup()) {
            runDiscovery();
        }
        bootstrapped = true;
    }

    public synchronized void runDiscovery() {
        discovery.discoverLoaderMetadata();
        discovery.censusForgeRegistries();
        integrations.registerDefaults();
        integrations.bindAll();
        rebuildKnowledge();
        emit(EngineEvent.DISCOVERY_COMPLETE, discovery.fingerprint());
    }

    public synchronized void onServerStarted(MinecraftServer server) {
        discovery.censusDatapackRegistries(server);
        rebuildKnowledge();
        world.attach(server, discovery);
        emit(EngineEvent.KNOWLEDGE_RECONCILED, discovery.fingerprint());
        emit(EngineEvent.WORLD_LOAD, world.snapshot().map(DimensionSnapshot::dimension).orElse("overworld"));
    }

    public synchronized void onServerStopping() {
        emit(EngineEvent.WORLD_SAVE, "overworld");
        world.detach();
    }

    public void emit(EngineEvent event, String detail) {
        WorldForgeLog.debug(LogCategory.CORE, "%s %s", event, detail == null ? "" : detail);
    }

    private void rebuildKnowledge() {
        knowledge.clear();
        for (DiscoveredMod mod : discovery.mods()) {
            Adapter adapter = findAdapterFor(mod.modId());
            AdapterState state = adapter == null ? AdapterState.UNBOUND : integrations.stateOf(adapter);
            String adapterId = adapter == null || state != AdapterState.BOUND ? null : adapter.id();
            List<IntegrationDomain> domains = adapter == null ? List.of() : List.of(adapter.domain());
            List<String> apis = detectApis(mod, adapter, state);
            knowledge.classify(mod, discovery.census(mod.modId()), apis, domains, state, adapterId);
        }
        WorldForgeLog.info(LogCategory.DISCOVERY, "Knowledge: %d known, %d partial, %d unknown",
                knowledge.count(net.worldforge.api.knowledge.KnowledgeStatus.KNOWN),
                knowledge.count(net.worldforge.api.knowledge.KnowledgeStatus.PARTIALLY_KNOWN),
                knowledge.count(net.worldforge.api.knowledge.KnowledgeStatus.UNKNOWN));
    }

    private Adapter findAdapterFor(String modId) {
        for (Adapter adapter : integrations.adapters()) {
            if (adapter.targetModIds().contains(modId)) {
                return adapter;
            }
        }
        return null;
    }

    private static List<String> detectApis(DiscoveredMod mod, Adapter adapter, AdapterState state) {
        if (adapter != null && state == AdapterState.BOUND) {
            return List.of(adapter.id());
        }
        if (adapter != null && state == AdapterState.SKIPPED_NO_API) {
            return List.of("detected-target:" + adapter.id());
        }
        if ("jei".equals(mod.modId()) || "curios".equals(mod.modId())) {
            return List.of("loader-visible-api");
        }
        return List.of();
    }

    @Override
    public Collection<DiscoveredMod> discoveredMods() {
        return discovery.mods();
    }

    @Override
    public Optional<DiscoveredMod> mod(String modId) {
        return discovery.get(modId);
    }

    @Override
    public Optional<ModKnowledge> knowledge(String modId) {
        return knowledge.get(modId);
    }

    @Override
    public KnowledgeLayer knowledgeLayer() {
        return knowledge;
    }

    @Override
    public Optional<Adapter> adapter(IntegrationDomain domain) {
        return integrations.byDomain(domain);
    }

    @Override
    public boolean isIntegrationBound(String modId) {
        Adapter adapter = findAdapterFor(modId);
        return adapter != null && adapter.isBound();
    }

    @Override
    public Optional<DimensionSnapshot> dimensionSnapshot() {
        world.refreshSnapshot();
        return world.snapshot();
    }

    @Override
    public Collection<Region> regions() {
        return world.regions();
    }

    @Override
    public Optional<Region> region(String id) {
        return world.region(id);
    }

    @Override
    public Collection<PointOfInterest> pointsOfInterest() {
        return world.pointsOfInterest();
    }

    @Override
    public Collection<WorldEvent> recentWorldEvents() {
        return world.recentEvents();
    }

    @Override
    public boolean registerRegion(Region region) {
        boolean ok = world.registerRegion(region);
        if (ok) {
            emit(EngineEvent.REGION_REGISTERED, region.id());
        }
        return ok;
    }

    @Override
    public boolean registerPointOfInterest(PointOfInterest poi) {
        boolean ok = world.registerPoi(poi);
        if (ok) {
            emit(EngineEvent.POI_REGISTERED, poi.id());
        }
        return ok;
    }

    @Override
    public WorldEvent postWorldEvent(String type, String payload) {
        WorldEvent event = world.postEvent(type, payload);
        emit(EngineEvent.WORLD_EVENT, event.type() + " " + event.payload());
        return event;
    }

    public ModDiscoveryService discovery() {
        return discovery;
    }

    public IntegrationManager integrations() {
        return integrations;
    }

    public WorldStateService world() {
        return world;
    }
}
