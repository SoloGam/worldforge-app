package net.worldforge.event;

import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.worldforge.api.event.EngineEvent;
import net.worldforge.core.WorldForgeCore;
import net.worldforge.core.config.WorldForgeConfig;
import net.worldforge.core.logging.LogCategory;
import net.worldforge.core.logging.WorldForgeLog;

/**
 * Narrow Forge subscription set. High-volume events stay behind the
 * experimental config flag and are not registered in this class at all
 * until that work lands — avoiding a hidden tick cost.
 */
public final class EventRouter {
    private final WorldForgeCore core;

    public EventRouter(WorldForgeCore core) {
        this.core = core;
    }

    @SubscribeEvent
    public void onServerStarted(ServerStartedEvent event) {
        WorldForgeLog.info(LogCategory.WORLD, "Server started");
        core.onServerStarted(event.getServer());
        core.emit(EngineEvent.SERVER_START, "server");
    }

    @SubscribeEvent
    public void onServerStopping(ServerStoppingEvent event) {
        core.onServerStopping();
        core.emit(EngineEvent.SERVER_STOP, "server");
    }

    @SubscribeEvent
    public void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity().level() instanceof ServerLevel) {
            core.world().refreshSnapshot();
            core.emit(EngineEvent.PLAYER_LOGIN, event.getEntity().getGameProfile().getName());
        }
    }

    @SubscribeEvent
    public void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        core.emit(EngineEvent.PLAYER_LOGOUT, event.getEntity().getGameProfile().getName());
    }

    @SubscribeEvent
    public void onPlayerChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        core.emit(EngineEvent.DIMENSION_CHANGE, event.getEntity().getGameProfile().getName()
                + " -> " + event.getTo().location());
    }

    public static boolean experimentalEnabled() {
        return WorldForgeConfig.experimentalFeatures();
    }
}
