package net.worldforge.integration;

import net.worldforge.api.integration.Adapter;
import net.worldforge.api.integration.AdapterState;
import net.worldforge.api.integration.IntegrationDomain;
import net.worldforge.core.config.WorldForgeConfig;
import net.worldforge.core.logging.LogCategory;
import net.worldforge.core.logging.WorldForgeLog;
import net.worldforge.integration.adapters.CombatSystemAdapter;
import net.worldforge.integration.adapters.MagicSystemAdapter;
import net.worldforge.integration.adapters.QuestAdapter;
import net.worldforge.integration.adapters.TechnologyAdapter;
import net.worldforge.integration.adapters.WorldgenAdapter;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Owns optional adapters. A missing target never fails WorldForge load.
 */
public final class IntegrationManager {
    private final List<Adapter> adapters = new ArrayList<>();
    private final Map<IntegrationDomain, Adapter> byDomain = new EnumMap<>(IntegrationDomain.class);

    public void registerDefaults() {
        adapters.clear();
        byDomain.clear();
        register(new MagicSystemAdapter(WorldForgeConfig.magicEnabled()));
        register(new CombatSystemAdapter(WorldForgeConfig.combatEnabled()));
        register(new TechnologyAdapter(WorldForgeConfig.technologyEnabled()));
        register(new QuestAdapter(WorldForgeConfig.questEnabled()));
        register(new WorldgenAdapter(WorldForgeConfig.worldgenEnabled()));
    }

    public void register(Adapter adapter) {
        adapters.add(adapter);
        byDomain.put(adapter.domain(), adapter);
    }

    public void bindAll() {
        int bound = 0;
        for (Adapter adapter : adapters) {
            try {
                if (adapter.tryBind()) {
                    bound++;
                }
            } catch (RuntimeException ex) {
                WorldForgeLog.error(LogCategory.INTEGRATION, "Adapter " + adapter.id() + " failed; continuing", ex);
                adapter.unbind();
            }
        }
        WorldForgeLog.info(LogCategory.INTEGRATION, "Adapters bound: %d / %d", bound, adapters.size());
    }

    public List<Adapter> adapters() {
        return List.copyOf(adapters);
    }

    public Optional<Adapter> byDomain(IntegrationDomain domain) {
        return Optional.ofNullable(byDomain.get(domain));
    }

    public AdapterState stateOf(Adapter adapter) {
        if (adapter instanceof NoOpAdapter noOp) {
            return noOp.state();
        }
        return adapter.isBound() ? AdapterState.BOUND : AdapterState.UNBOUND;
    }
}
