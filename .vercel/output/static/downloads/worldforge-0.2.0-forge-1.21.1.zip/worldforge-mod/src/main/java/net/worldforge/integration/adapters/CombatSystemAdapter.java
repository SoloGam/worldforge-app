package net.worldforge.integration.adapters;

import net.worldforge.api.integration.IntegrationDomain;
import net.worldforge.integration.NoOpAdapter;

import java.util.Set;

/**
 * Combat abstraction. Vanilla combat is always inspectable through Minecraft
 * itself; third-party combat mods stay unbound until an official API is used.
 */
public final class CombatSystemAdapter extends NoOpAdapter {
    public CombatSystemAdapter(boolean enabled) {
        super("worldforge:combat", IntegrationDomain.COMBAT, Set.of("apotheosis", "bettercombat"), enabled);
    }
}
