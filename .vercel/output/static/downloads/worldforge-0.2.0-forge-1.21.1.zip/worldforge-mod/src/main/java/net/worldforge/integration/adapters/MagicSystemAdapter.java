package net.worldforge.integration.adapters;

import net.worldforge.api.integration.IntegrationDomain;
import net.worldforge.integration.NoOpAdapter;

import java.util.Set;

/**
 * Magic-system adapter.
 *
 * Known targets (not dependencies):
 * - ars_nouveau: public documented API exists; binding lands in a later phase.
 * - irons_spellbooks: partial public surface; treated as partial until an adapter is written.
 *
 * This class currently refuses to bind. That is intentional: detecting a magic
 * mod is not the same as understanding it.
 */
public final class MagicSystemAdapter extends NoOpAdapter {
    public MagicSystemAdapter(boolean enabled) {
        super("worldforge:magic", IntegrationDomain.MAGIC, Set.of("ars_nouveau", "irons_spellbooks"), enabled);
    }
}
