# Roadmap

## Done — 0.1.0 (Phases 1–5)

- Forge 1.21.1 / 52.1.0 workspace
- Config, structured logging, lifecycle
- Service registry
- Mod discovery + registry census
- Knowledge layer with honest status
- Persistent SavedData + schema + fingerprint
- Integration manager and domain adapter stubs
- `/worldforge` diagnostics

## Done — 0.2.0 (Phase 6)

- Dimension snapshot (time, weather, difficulty)
- Region registry (authored, not a world scan)
- Point-of-interest API
- Pack-authored world event bus
- SavedData schema 2

## Done — 0.3.0 (Phases 7–8, start of 9)

- Magic descriptor catalog; detect-only for Ars Nouveau / Iron's Spells
- Vanilla combat adapter bound through official damage-type / attribute / entity-category registries
- Public `WorldForgeEventBus`
- JSON adapter descriptors

## Next — Phase 9 remainder

- Isolated optional Gradle source set for one documented magic API (Ars Nouveau) — still not a hard dependency
- Compatibility test pack

## Later — Phase 10

- Profiling pass (allocation, registry census cost on 200-mod packs)
- High-volume combat events behind `experimentalFeatures`

## Non-goals for 0.x

- Shipping gameplay content
- Mixins against other mods
- Downloading code at runtime
- Pretending to understand closed systems
